<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bảo trì trang web</title>
	<link rel="stylesheet" href="<?php echo $_DOMAIN; ?>admin/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<div class="row text-center">
			<h1>Trang web chúng tôi hiện đang bảo trì, vui lòng quay lại sau.</h1>
		</div>
	</div>
</body>
</html>